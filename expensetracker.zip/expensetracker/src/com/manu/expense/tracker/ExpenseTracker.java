package com.manu.expense.tracker;

import java.util.ArrayList;
import java.util.List;

public class ExpenseTracker {
	private List<Expense> expenses;

	public ExpenseTracker() {
		expenses = new ArrayList<>();
	}

	public void addExpense(Expense expense) {
		expenses.add(expense);
	}

	public void deleteExpense(int index) {
		expenses.remove(index);
	}

	public void editExpense(int index, Expense expense) {
		expenses.set(index, expense);
	}

	public List<Expense> getExpenses() {
		return expenses;
	}

	public static void main(String[] args) {
		ExpenseTracker tracker = new ExpenseTracker();

		Expense expense1 = new Expense("2023-06-01", "Groceries", "Food", 50.0);
		Expense expense2 = new Expense("2023-06-02", "Gas", "Transportation", 30.0);
		Expense expense3 = new Expense("2023-06-03", "Mobile", "Recharge", 230.0);

		tracker.addExpense(expense1);
		tracker.addExpense(expense2);
		tracker.addExpense(expense3);

		List<Expense> expenses = tracker.getExpenses();
		for (Expense expense : expenses) {
			System.out.println("Date: " + expense.getDate());
			System.out.println("Description: " + expense.getDescription());
			System.out.println("Category: " + expense.getCategory());
			System.out.println("Amount: " + expense.getAmount());
			System.out.println("-----------------------");
		}
	}
}